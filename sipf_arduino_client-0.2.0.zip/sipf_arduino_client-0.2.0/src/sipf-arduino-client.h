#ifndef SIPF_ARDUINO_CLIENT_H
#define SIPF_ARDUINO_CLIENT_H

#include "SipfClient.h"

#endif  //SIPF_ARDUINO_CLIENT_H
